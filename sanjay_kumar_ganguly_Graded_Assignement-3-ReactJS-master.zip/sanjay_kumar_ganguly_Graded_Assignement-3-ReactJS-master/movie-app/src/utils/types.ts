type LoadingStatus = "LOADING" | "LOADED" | "ERROR";

export type { LoadingStatus };
