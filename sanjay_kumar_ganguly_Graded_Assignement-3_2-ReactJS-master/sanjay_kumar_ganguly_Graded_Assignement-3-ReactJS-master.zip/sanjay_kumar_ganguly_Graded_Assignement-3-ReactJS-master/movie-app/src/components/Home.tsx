const Home = () => {
    return (
        <main>
            <section>
                <header>
                    <h1>Movies on the Tip</h1>
                </header>
                <hr />
                <p>
                    Movies on the Tip is an online movie manager whose responsibility is to take care of all
                    the activities a user can do on this portal.
                </p>
            </section>
        </main>
    );
};

export default Home;